import os
import re
import urllib.parse

# ================= НАСТРОЙКИ =================
SOURCE_DIR = r"C:\Program Files (x86)\Steam\steamapps\common\DeathRoadToCanada\deathforth"
OUTPUT_FILE = "developer_comments.html"

# Если хочешь, можешь указать ветку вручную (например: "stomach_update", "beta", "Public")
# Если оставить пустым (""), скрипт попытается угадать её автоматически из Steam
MANUAL_BRANCH_NAME = ""
# =============================================


def get_steam_branch_version():
    if MANUAL_BRANCH_NAME:
        return f"Steam Branch: {MANUAL_BRANCH_NAME}"

    try:
        steamapps_dir = os.path.abspath(
            os.path.join(SOURCE_DIR, "..", "..", "..")
        )
        # Ищем файл манифеста в парент-папке steamapps
        manifest_path = os.path.join(steamapps_dir, "appmanifest_252610.acf")

        if os.path.exists(manifest_path):
            with open(
                manifest_path, "r", encoding="utf-8", errors="ignore"
            ) as f:
                content = f.read()
                # Ищем поле "LastOwner" или название беты/оживления в манифесте
                # Попробуем найти секцию с именем беты или buildid
                match_branch = re.search(
                    r'"Universe"\s+"(\d+)"', content
                )  # к примеру
                match_build = re.search(r'"buildid"\s+"(\d+)"', content)
                if match_build:
                    # Попробуем поискать имя ветки (beta / pubbet / etc)
                    match_name = re.search(r'"name"\s+"([^"]+)"', content)
                    branch_info = (
                        match_name.group(1) if match_name else "Public"
                    )
                    return f"Steam Version / Build ID: {match_build.group(1)} ({branch_info})"
    except Exception:
        pass

    # Альтернатива: проверяем путь к игре на наличие слов бетек из твоего скриншота
    path_lower = SOURCE_DIR.lower()
    for branch in [
        "beta",
        "crashfix",
        "stomach_update",
        "retina_update",
        "public",
    ]:
        if branch in path_lower:
            return f"Steam Branch: {branch}"

    return "Steam Branch: Public / Standard"


def extract_dev_comments_html():
    game_version = get_steam_branch_version()
    comment_pattern = re.compile(r"(?://|\\\\)(.*)")

    files_checked = 0
    files_with_comments = 0
    total_comments = 0

    if not os.path.exists(SOURCE_DIR):
        print(f"ERROR: Folder not found: {SOURCE_DIR}")
        return

    html_content = []
    html_content.append(
        f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Developer Comments — Death Road to Canada</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; max-width: 1000px; margin: 40px auto; padding: 0 20px; background: #f4f6f9; }}
        h1 {{ color: #2c3e50; border-bottom: 2px solid #d1d5db; padding-bottom: 10px; margin-bottom: 5px; }}
        .version-badge {{ display: inline-block; background: #dbeafe; color: #1e40af; padding: 6px 12px; border-radius: 6px; font-size: 15px; font-weight: 600; margin-bottom: 20px; }}
        .stats {{ background: #e0f2fe; color: #0369a1; padding: 15px; border-radius: 8px; margin-bottom: 25px; font-weight: 500; }}
        .file-block {{ background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }}
        .file-title {{ margin-top: 0; font-size: 18px; border-bottom: 1px solid #f3f4f6; padding-bottom: 10px; }}
        .file-title a {{ color: #2563eb; text-decoration: none; }}
        .file-title a:hover {{ text-decoration: underline; }}
        ul {{ padding-left: 20px; margin: 0; }}
        li {{ margin-bottom: 10px; font-size: 15px; }}
        .line-link {{ font-family: monospace; background: #f3f4f6; color: #4b5563; padding: 2px 6px; border-radius: 4px; text-decoration: none; font-size: 85%; margin-right: 8px; border: 1px solid #e5e7eb; display: inline-block; }}
        .line-link:hover {{ background: #e5e7eb; color: #1f2937; }}
        .comment-text {{ font-family: monospace; color: #111827; }}
        .note {{ font-size: 13px; color: #6b7280; margin-bottom: 20px; }}
    </style>
</head>
<body>
    <h1>💬 Developer Comments (Death Road to Canada)</h1>
    <div class="version-badge">🎮 {game_version}</div>
    <div class="note">💡 Clicking on file names or line numbers will open them directly in <b>VS Code</b> at the exact line.</div>
"""
    )

    temp_body = []

    for root, dirs, files in os.walk(SOURCE_DIR):
        for file in sorted(files):
            if file.lower().endswith(".df"):
                files_checked += 1
                file_path = os.path.join(root, file)
                file_comments = []

                try:
                    with open(
                        file_path, "r", encoding="utf-8", errors="replace"
                    ) as in_f:
                        for line_num, line in enumerate(in_f, start=1):
                            match = comment_pattern.search(line)
                            if match:
                                clean_text = match.group(1).strip()
                                full_comment = (
                                    f"// {clean_text}"
                                    if "//" in line
                                    else f"\\\\ {clean_text}"
                                )
                                file_comments.append((line_num, full_comment))
                except Exception as e:
                    print(f"Failed to read file {file}: {e}")
                    continue

                if file_comments:
                    files_with_comments += 1
                    total_comments += len(file_comments)

                    rel_path = os.path.relpath(file_path, SOURCE_DIR)
                    abs_path = os.path.abspath(file_path)

                    base_vscode_uri = f"vscode://file/{abs_path.replace(os.sep, '/')}"

                    temp_body.append(
                        f'    <div class="file-block">\n'
                        f'        <h3 class="file-title">📁 File: <a href="{base_vscode_uri}" title="Open in VS Code">{rel_path}</a></h3>\n'
                        f'        <ul>\n'
                    )

                    for line_num, comment in file_comments:
                        line_vscode_uri = f"{base_vscode_uri}:{line_num}"
                        safe_comment = (
                            comment.replace("&", "&amp;")
                            .replace("<", "&lt;")
                            .replace(">", "&gt;")
                        )

                        temp_body.append(
                            f'            <li><a href="{line_vscode_uri}" class="line-link" title="Open in VS Code at line {line_num}">line {line_num}</a><span class="comment-text">{safe_comment}</span></li>\n'
                        )

                    temp_body.append(f'        </ul>\n    </div>\n')

    html_content.append(
        f'    <div class="stats">Checked files: {files_checked} | Files with comments: {files_with_comments} | Total comments found: {total_comments}</div>\n'
    )
    html_content.extend(temp_body)
    html_content.append("</body>\n</html>")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as out_f:
        out_f.write("".join(html_content))

    print(f"Detected Version: {game_version}")
    print(f"Checked .df files: {files_checked}")
    print(f"Files with comments processed: {files_with_comments}")
    print(f"Total comments found: {total_comments}")
    print(
        f"Interactive HTML file successfully saved: '{OUTPUT_FILE}' (open it in your browser)"
    )


if __name__ == "__main__":
    extract_dev_comments_html()